import re

filepath = "FutureWork/Appendices/AppendixK/NuclearFusionFission.lean"
with open(filepath, "r", encoding="utf-8") as f:
    c = f.read()

# Replace (x : ℝ)^y.y with Real.rpow (x : ℝ) (y.y : ℝ)
# Pattern: \((\d+ | [A-Za-z_]+ | [A-Za-z_]+ \+ \d+) : ℝ\)\^(0\.\d+)
c = re.sub(
    r"\(([^)]+) : ℝ\)\^(0\.\d+)",
    r"Real.rpow (\1 : ℝ) (\2 : ℝ)",
    c
)

with open(filepath, "w", encoding="utf-8") as f:
    f.write(c)

print("Done")
