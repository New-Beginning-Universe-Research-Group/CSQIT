import re

filepath = "FutureWork/Appendices/AppendixK/NuclearFusionFission.lean"
with open(filepath, "r", encoding="utf-8") as f:
    c = f.read()

c = re.sub(r"^/--$", "/-", c, flags=re.MULTILINE)

with open(filepath, "w", encoding="utf-8") as f:
    f.write(c)

print("Done")
